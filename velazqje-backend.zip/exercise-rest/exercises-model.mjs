// Import dependencies.
import mongoose from "mongoose";
import "dotenv/config";

// Connect to the Atlas cluster or local MongoDB.
mongoose.connect(process.env.MONGODB_CONNECT_STRING, { useNewUrlParser: true });
const db = mongoose.connection;

// Confirm that the database has connected
// and print a message in the console.
db.once("open", () => {
  console.log("Successfully connected to MongoDB using Mongoose!");
});

// Define the collection's schema. --> EXERCISE
const exerciseSchema = mongoose.Schema({
  name: { type: String, required: true },
  reps: { type: Number, required: true },
  weight: { type: Number, required: true },
  unit: { type: String, required: true, default: "lbs" },
  date: { type: Date, required: true, default: new Date()},
});

// Compile the model from the schema. --> EXERCISE
const Exercise = mongoose.model("Exercise", exerciseSchema);

// CREATE model *****************************************

/*
Create a workout
* @param {String} name : required
* @param {Number} reps : required
* @param {Number} weight : required
* @param {String} unit date : required
* @param {Date} : required
* @returns A promise. Resolves to the JavaScript object for the document created by calling save
*/
const createExercise = async (name, reps, weight, unit, date) => {
  const exercise = new Exercise({
    name: name,
    reps: reps,
    weight: weight,
    unit: unit,
    date: date,
  });
  // to persist workout instance to MongoDB, save
  return exercise.save();
};

// RETRIEVE models *****************************************
// Retrieve based on a filter and return a promise.
const findExercises = async (filter) => {
  const query = Exercise.find(filter);
  return query.exec();
};

const findExerciseById = async (_id) => {
  const query = Exercise.findById(_id);
  return query.exec();
};

// UPDATE model *****************************************
// REPLACE model *****************************************************
const replaceExercise = async (_id, name, reps, weight, unit, date) => {
  const result = await Exercise.replaceOne({_id: _id }, {
      name: name,
      reps: reps,
      weight: weight,
      unit: unit,
      date: date
  });
  return result.modifiedCount;
}


// DELETE model based on ID  *****************************************
const deleteById = async (_id) => {
  const result = await Exercise.deleteOne({ _id: _id });
  return result.deletedCount;
};

// Export our variables for use in the controller file.
export {
  createExercise,  // create
  findExercises,   // retrieve
  findExerciseById,  // retrieve
  replaceExercise,  // update
  deleteById,  // delete
};
