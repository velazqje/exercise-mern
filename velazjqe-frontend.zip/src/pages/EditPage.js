import React from "react";
import { useHistory } from "react-router-dom";
import { useState } from "react";

export const EditPage = ({ exercise: exercise }) => {
  const [name, setName] = useState(exercise.name);
  const [reps, setReps] = useState(exercise.reps);
  const [weight, setWeight] = useState(exercise.weight);
  const [unit, setUnit] = useState(exercise.unit);
  const [date, setDate] = useState(exercise.date);

  const history = useHistory();

  const editExercise = async () => {
    const response = await fetch(`/exercises/${exercise._id}`, {
      method: "PUT",
      body: JSON.stringify({
        name: name,
        reps: reps,
        weight: weight,
        unit: unit,
        date: date,
      }),
      headers: { "Content-Type": "application/json" },
    });

    if (response.status === 200) {
      alert("Successfully edited the exercise!");
    } else {
      const errMessage = await response.json();
      alert(
        `Failed to update document. Status ${response.status}. ${errMessage.Error}`
      );
    }
    history.push("/");
  };

  return (
    <>
      <article>
        <h2>Edit a workout</h2>
        <p>
          Son of a peach! Correct any mistakes made when entering your workout
          below.
        </p>
        <form
          onSubmit={(e) => {
            e.preventDefault();
          }}
        >
          <fieldset id="editfieldset">
            <legend>Which exercise are you editing?</legend>
            <ul>
              <li>
                <label for="title">Exercise name</label>
                <input
                  type="text"
                  placeholder="eg: squats"
                  value={name}
                  onChange={(e) => setName(e.target.value)}
                  id="name"
                />
              </li>
              <li>
                <label for="reps">Reps completed</label>
                <input
                  type="number"
                  value={reps}
                  min="0"
                  placeholder="5"
                  onChange={(e) => setReps(e.target.value)}
                  id="reps"
                />
              </li>
              <li>
                <label for="weight">Weight</label>
                <input
                  type="number"
                  min="0"
                  placeholder="Weight"
                  value={weight}
                  onChange={(e) => setWeight(e.target.value)}
                  id="weight"
                />
              </li>
              <li>
                <label for="unit">Unit</label>
                <select>
                  <option
                    value="lbs"
                    onChange={(e) => setUnit(e.target.value)}
                    id="unit"
                  >
                    lbs
                  </option>
                  <option
                    value="kgs"
                    onChange={(e) => setUnit(e.target.value)}
                    id="unit"
                  >
                    kgs
                  </option>
                  <option
                    value="miles"
                    onChange={(e) => setUnit(e.target.value)}
                    id="unit"
                  >
                    miles
                  </option>
                </select>
              </li>
              <li>
                <label for="date">Date</label>
                <input
                  type="date"
                  placeholder="Date completed"
                  value={date}
                  onChange={(e) => setDate(e.target.value)}
                  id="date"
                />
              </li>
              <li>
                <label for="save">
                  <button type="save" onClick={editExercise} id="save">
                    Update Workout
                  </button>{" "}
                </label>
              </li>
            </ul>
          </fieldset>
        </form>
      </article>
    </>
  );
};
export default EditPage;
