import { GrFormEdit, GrFormClose } from "react-icons/gr";

function Row({ exercise, onDelete, onEdit }) {
  return (
    <tr>
      <td  class="tdtext">{exercise.name}</td>
      <td class="tdnum">{exercise.reps}</td>
      <td class="tdnum">{exercise.weight}</td>
      <td class="tdtext">{exercise.unit}</td>
      <td class="tdtext">{exercise.date.toLocaleString("en-US").substring(0, 10)}</td>
      <td class="icon">
        <GrFormEdit onClick={() => onEdit(exercise)} />
      </td>
      <td class="icon">
        <GrFormClose onClick={() => onDelete(exercise._id)} />
      </td>
    </tr>
  );
}

export default Row;
