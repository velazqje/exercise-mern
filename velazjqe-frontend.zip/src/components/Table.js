import Row from "./Row";

function Table({ exercises, onDelete, onEdit }) {
  return (
    <table>
      <thead>
        <tr>
          <th class="tdtext">Name</th>
          <th class="tdnum">Reps</th>
          <th class="tdnum">Weight/</th>
          <th class="tdtext">Unit</th>
          <th class="tdtext">Date</th>
          <th></th>
          <th></th>
        </tr>
      </thead>
      <tbody>
        {exercises.map((exercise, i) => (
          <Row
            exercise={exercise}
            onDelete={onDelete}
            onEdit={onEdit}
            key={i}
          />
        ))}
      </tbody>
      <tfoot></tfoot>
    </table>
  );
}

export default Table;
